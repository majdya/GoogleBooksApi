# angular2-books-api
Demo for google books api with Angular 2


Take checkout of repository and run following commands

On MAC
sudo npm install or yarn
sudo typings install


On Windows
npm install or yarn
typings install


Run following command to run application - gulp serve



Package removed from now - "typings": "^1.0.4"