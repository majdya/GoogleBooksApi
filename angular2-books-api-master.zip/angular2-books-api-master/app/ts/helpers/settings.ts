export const _settings = {
	buildPath: 'app/templates/'
};
