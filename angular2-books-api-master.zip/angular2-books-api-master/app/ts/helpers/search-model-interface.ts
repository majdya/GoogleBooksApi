export interface searchModelInterface {
	searchQuery: string;
	searchLimit: number;
	sortOrder: string;
	localSortKey: string;
}