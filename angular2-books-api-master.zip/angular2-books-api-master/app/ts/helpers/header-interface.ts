export interface headerInterface {
	name: string;
	clickFunc: string;
	text: string;
	showBtn: Boolean;
}
